//sample.c
int sum(int x, int y){
    return x+y;
}

int main(){
    sum(2,3);
    return 0;
} 