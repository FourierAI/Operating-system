//sample2.c
int global_var = 5;

int main(){
    static int static_var = 6;
    return 0;
} 